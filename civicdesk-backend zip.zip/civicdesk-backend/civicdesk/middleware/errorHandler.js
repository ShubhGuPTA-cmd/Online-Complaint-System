// ─────────────────────────────────────────────
//  middleware/errorHandler.js
// ─────────────────────────────────────────────

function errorHandler(err, req, res, next) {
  console.error(`[ERROR] ${req.method} ${req.path} →`, err.message);

  // MySQL duplicate entry
  if (err.code === 'ER_DUP_ENTRY') {
    return res.status(409).json({ error: 'Duplicate entry — record already exists.' });
  }

  // MySQL foreign key constraint
  if (err.code === 'ER_NO_REFERENCED_ROW_2') {
    return res.status(400).json({ error: 'Referenced record does not exist.' });
  }

  res.status(err.status || 500).json({
    error: err.message || 'Internal server error.',
  });
}

module.exports = errorHandler;
