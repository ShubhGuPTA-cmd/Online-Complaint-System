// ─────────────────────────────────────────────
//  routes/questions.js — Feedback Q&A
// ─────────────────────────────────────────────

const express = require('express');
const router  = express.Router();
const pool    = require('../db');
const { authenticate, requireRole } = require('../middleware/auth');

// GET /api/questions
router.get('/', authenticate, async (req, res, next) => {
  try {
    const [rows] = await pool.execute(
      `SELECT q.qID, q.title, COUNT(a.ansID) AS answerCount
       FROM Questions q
       LEFT JOIN Answers a ON q.qID = a.qID
       GROUP BY q.qID, q.title
       ORDER BY q.qID ASC`
    );
    res.json(rows);
  } catch (err) {
    next(err);
  }
});

// POST /api/questions — Admin only
router.post('/', authenticate, requireRole('Admin'), async (req, res, next) => {
  const { title } = req.body;
  if (!title) return res.status(400).json({ error: 'title is required.' });

  try {
    const [result] = await pool.execute(
      'INSERT INTO Questions (title) VALUES (?)', [title]
    );
    res.status(201).json({ message: 'Question created.', qID: result.insertId });
  } catch (err) {
    next(err);
  }
});

// POST /api/questions/:qID/answers — Submit an answer (any authenticated user)
router.post('/:qID/answers', authenticate, async (req, res, next) => {
  try {
    const [result] = await pool.execute(
      'INSERT INTO Answers (qID) VALUES (?)', [req.params.qID]
    );
    res.status(201).json({ message: 'Answer submitted.', ansID: result.insertId });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
