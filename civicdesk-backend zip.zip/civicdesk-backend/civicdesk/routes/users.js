// ─────────────────────────────────────────────
//  routes/users.js — User Management
// ─────────────────────────────────────────────

const express = require('express');
const router  = express.Router();
const pool    = require('../db');
const { authenticate, requireRole } = require('../middleware/auth');

// GET /api/users — Admin only
router.get('/', authenticate, requireRole('Admin'), async (req, res, next) => {
  try {
    const [rows] = await pool.execute(
      `SELECT u.userId, u.username, u.email, u.alt_email, u.roleId,
              r.roleType, p.phone_no
       FROM User u
       JOIN Roles r ON u.roleId = r.roleId
       LEFT JOIN User_Phone_No p ON u.userId = p.userId
       ORDER BY u.userId ASC`
    );
    res.json(rows);
  } catch (err) {
    next(err);
  }
});

// GET /api/users/:id
router.get('/:id', authenticate, async (req, res, next) => {
  try {
    const [rows] = await pool.execute(
      `SELECT u.userId, u.username, u.email, u.alt_email, u.roleId,
              r.roleType, p.phone_no
       FROM User u
       JOIN Roles r ON u.roleId = r.roleId
       LEFT JOIN User_Phone_No p ON u.userId = p.userId
       WHERE u.userId = ?`,
      [req.params.id]
    );
    if (!rows.length) return res.status(404).json({ error: 'User not found.' });
    res.json(rows[0]);
  } catch (err) {
    next(err);
  }
});

// POST /api/users — Admin only
router.post('/', authenticate, requireRole('Admin'), async (req, res, next) => {
  const { username, email, alt_email, password, roleId, phone_no } = req.body;

  if (!username || !email || !password || !roleId) {
    return res.status(400).json({ error: 'username, email, password and roleId are required.' });
  }

  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();

    const [result] = await conn.execute(
      'INSERT INTO User (username, email, alt_email, password, roleId) VALUES (?, ?, ?, ?, ?)',
      [username, email, alt_email || null, password, roleId]
    );
    const userId = result.insertId;

    if (phone_no) {
      await conn.execute(
        'INSERT INTO User_Phone_No (phone_no, userId) VALUES (?, ?)',
        [phone_no, userId]
      );
    }

    await conn.commit();
    res.status(201).json({ message: 'User created successfully.', userId });
  } catch (err) {
    await conn.rollback();
    next(err);
  } finally {
    conn.release();
  }
});

// DELETE /api/users/:id — Admin only
router.delete('/:id', authenticate, requireRole('Admin'), async (req, res, next) => {
  try {
    await pool.execute('DELETE FROM User_Phone_No WHERE userId = ?', [req.params.id]);
    const [result] = await pool.execute('DELETE FROM User WHERE userId = ?', [req.params.id]);
    if (!result.affectedRows) return res.status(404).json({ error: 'User not found.' });
    res.json({ message: 'User deleted.' });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
