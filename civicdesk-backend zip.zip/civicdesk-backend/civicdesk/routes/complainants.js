// ─────────────────────────────────────────────
//  routes/complainants.js
// ─────────────────────────────────────────────

const express = require('express');
const router  = express.Router();
const pool    = require('../db');
const { authenticate } = require('../middleware/auth');

// GET /api/complainants
router.get('/', authenticate, async (req, res, next) => {
  try {
    const [rows] = await pool.execute(
      `SELECT c.nationalID, c.name, c.address,
              g.gender, m.mobile
       FROM Complainant c
       LEFT JOIN Complainant_Gender g ON c.nationalID = g.nationalID
       LEFT JOIN Complainant_Mobile m ON c.nationalID = m.nationalID
       ORDER BY c.name ASC`
    );
    res.json(rows);
  } catch (err) {
    next(err);
  }
});

// GET /api/complainants/:nationalID
router.get('/:nationalID', authenticate, async (req, res, next) => {
  try {
    const [rows] = await pool.execute(
      `SELECT c.nationalID, c.name, c.address,
              g.gender, m.mobile
       FROM Complainant c
       LEFT JOIN Complainant_Gender g ON c.nationalID = g.nationalID
       LEFT JOIN Complainant_Mobile m ON c.nationalID = m.nationalID
       WHERE c.nationalID = ?`,
      [req.params.nationalID]
    );
    if (!rows.length) return res.status(404).json({ error: 'Complainant not found.' });
    res.json(rows[0]);
  } catch (err) {
    next(err);
  }
});

// POST /api/complainants
router.post('/', authenticate, async (req, res, next) => {
  const { nationalID, name, address, gender, mobile } = req.body;

  if (!nationalID || !name) {
    return res.status(400).json({ error: 'nationalID and name are required.' });
  }

  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();

    await conn.execute(
      'INSERT INTO Complainant (nationalID, name, address) VALUES (?, ?, ?)',
      [nationalID, name, address || null]
    );

    if (gender) {
      await conn.execute(
        'INSERT INTO Complainant_Gender (gender, nationalID) VALUES (?, ?)',
        [gender, nationalID]
      );
    }

    if (mobile) {
      await conn.execute(
        'INSERT INTO Complainant_Mobile (mobile, nationalID) VALUES (?, ?)',
        [mobile, nationalID]
      );
    }

    await conn.commit();
    res.status(201).json({ message: 'Complainant registered.', nationalID });
  } catch (err) {
    await conn.rollback();
    next(err);
  } finally {
    conn.release();
  }
});

// PUT /api/complainants/:nationalID
router.put('/:nationalID', authenticate, async (req, res, next) => {
  const { name, address, gender, mobile } = req.body;
  const { nationalID } = req.params;

  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();

    await conn.execute(
      'UPDATE Complainant SET name = ?, address = ? WHERE nationalID = ?',
      [name, address || null, nationalID]
    );

    if (gender) {
      const [exists] = await conn.execute(
        'SELECT 1 FROM Complainant_Gender WHERE nationalID = ?', [nationalID]
      );
      if (exists.length) {
        await conn.execute('UPDATE Complainant_Gender SET gender = ? WHERE nationalID = ?', [gender, nationalID]);
      } else {
        await conn.execute('INSERT INTO Complainant_Gender (gender, nationalID) VALUES (?, ?)', [gender, nationalID]);
      }
    }

    if (mobile) {
      const [exists] = await conn.execute(
        'SELECT 1 FROM Complainant_Mobile WHERE nationalID = ?', [nationalID]
      );
      if (exists.length) {
        await conn.execute('UPDATE Complainant_Mobile SET mobile = ? WHERE nationalID = ?', [mobile, nationalID]);
      } else {
        await conn.execute('INSERT INTO Complainant_Mobile (mobile, nationalID) VALUES (?, ?)', [mobile, nationalID]);
      }
    }

    await conn.commit();
    res.json({ message: 'Complainant updated.' });
  } catch (err) {
    await conn.rollback();
    next(err);
  } finally {
    conn.release();
  }
});

module.exports = router;
