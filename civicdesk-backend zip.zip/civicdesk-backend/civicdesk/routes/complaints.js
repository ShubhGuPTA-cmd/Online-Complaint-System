// ─────────────────────────────────────────────
//  routes/complaints.js — Full Complaint CRUD
// ─────────────────────────────────────────────

const express = require('express');
const router  = express.Router();
const pool    = require('../db');
const { authenticate, requireRole } = require('../middleware/auth');

// ── Shared SELECT fragment ──────────────────
const COMPLAINT_SELECT = `
  SELECT
    comp.complaintID, comp.complaintNumber,
    comp.complaintDesc, comp.complaintDate,
    comp.nationalID,
    c.name   AS complainantName,
    c.address,
    g.gender,
    m.mobile,
    cs.id    AS statusId,
    s.statusType,
    cs.userId AS assignedOfficer,
    ca.causeID, ca.causeName,
    ca2.complaintActionID, ca2.actions,
    f.followupID, f.followupDate
  FROM Complaint comp
  JOIN  Complainant        c   ON comp.nationalID  = c.nationalID
  LEFT JOIN Complainant_Gender g ON c.nationalID   = g.nationalID
  LEFT JOIN Complainant_Mobile m ON c.nationalID   = m.nationalID
  LEFT JOIN ComplaintStatus    cs ON comp.complaintID = cs.complaintID
  LEFT JOIN Status             s  ON cs.id          = s.id
  LEFT JOIN ComplaintCauses    ca  ON comp.complaintID = ca.complaintID
  LEFT JOIN ComplaintActions   ca2 ON comp.complaintID = ca2.complaintID
  LEFT JOIN FollowUp           f   ON comp.complaintID = f.complaintID
`;

// GET /api/complaints
// Query params: ?search=water&status=2
router.get('/', authenticate, async (req, res, next) => {
  const { search, status } = req.query;
  let sql    = COMPLAINT_SELECT + ' WHERE 1=1';
  const params = [];

  if (search) {
    sql += ' AND (comp.complaintDesc LIKE ? OR comp.complaintNumber LIKE ? OR c.name LIKE ?)';
    const like = `%${search}%`;
    params.push(like, like, like);
  }
  if (status) {
    sql += ' AND cs.id = ?';
    params.push(parseInt(status));
  }

  sql += ' ORDER BY comp.complaintID DESC';

  try {
    const [rows] = await pool.execute(sql, params);
    res.json(rows);
  } catch (err) {
    next(err);
  }
});

// GET /api/complaints/track/:complaintNumber  (public — no auth needed)
router.get('/track/:complaintNumber', async (req, res, next) => {
  try {
    const [rows] = await pool.execute(
      COMPLAINT_SELECT + ' WHERE comp.complaintNumber = ?',
      [req.params.complaintNumber.toUpperCase()]
    );
    if (!rows.length) return res.status(404).json({ error: 'Complaint not found.' });
    res.json(rows[0]);
  } catch (err) {
    next(err);
  }
});

// GET /api/complaints/:id
router.get('/:id', authenticate, async (req, res, next) => {
  try {
    const [rows] = await pool.execute(
      COMPLAINT_SELECT + ' WHERE comp.complaintID = ?',
      [req.params.id]
    );
    if (!rows.length) return res.status(404).json({ error: 'Complaint not found.' });
    res.json(rows[0]);
  } catch (err) {
    next(err);
  }
});

// POST /api/complaints — Register new complaint
router.post('/', authenticate, async (req, res, next) => {
  const { complaintDesc, nationalID, causeName, userId } = req.body;

  if (!complaintDesc || !nationalID) {
    return res.status(400).json({ error: 'complaintDesc and nationalID are required.' });
  }

  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();

    // Auto-generate complaint number
    const [last] = await conn.execute(
      'SELECT complaintID FROM Complaint ORDER BY complaintID DESC LIMIT 1'
    );
    const nextId  = last.length ? last[0].complaintID + 1 : 1;
    const compNum = 'CMP' + String(nextId).padStart(3, '0');
    const today   = new Date().toISOString().split('T')[0];

    // Insert complaint
    const [result] = await conn.execute(
      'INSERT INTO Complaint (complaintNumber, complaintDesc, complaintDate, nationalID) VALUES (?, ?, ?, ?)',
      [compNum, complaintDesc, today, nationalID]
    );
    const complaintID = result.insertId;

    // Set initial status → Registered (id = 1)
    await conn.execute(
      'INSERT INTO ComplaintStatus (complaintID, userId, id) VALUES (?, ?, 1)',
      [complaintID, userId || req.user.userId]
    );

    // Insert cause
    if (causeName) {
      await conn.execute(
        'INSERT INTO ComplaintCauses (causeName, complaintID) VALUES (?, ?)',
        [causeName, complaintID]
      );
    }

    await conn.commit();
    res.status(201).json({
      message: 'Complaint registered successfully.',
      complaintID,
      complaintNumber: compNum,
    });
  } catch (err) {
    await conn.rollback();
    next(err);
  } finally {
    conn.release();
  }
});

// PATCH /api/complaints/:id/status — Update status, action, follow-up
router.patch('/:id/status', authenticate, requireRole('Admin', 'Officer'), async (req, res, next) => {
  const { statusId, userId, actions, followupDate } = req.body;

  if (!statusId) return res.status(400).json({ error: 'statusId is required.' });

  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const cid = req.params.id;

    // Update status
    await conn.execute(
      'UPDATE ComplaintStatus SET id = ?, userId = ? WHERE complaintID = ?',
      [statusId, userId || req.user.userId, cid]
    );

    // Upsert action
    if (actions !== undefined) {
      const [existAct] = await conn.execute(
        'SELECT complaintActionID FROM ComplaintActions WHERE complaintID = ?', [cid]
      );
      if (existAct.length) {
        await conn.execute(
          'UPDATE ComplaintActions SET actions = ? WHERE complaintID = ?', [actions, cid]
        );
      } else {
        await conn.execute(
          'INSERT INTO ComplaintActions (actions, complaintID) VALUES (?, ?)', [actions, cid]
        );
      }
    }

    // Upsert follow-up date
    if (followupDate) {
      const [existFU] = await conn.execute(
        'SELECT followupID FROM FollowUp WHERE complaintID = ?', [cid]
      );
      if (existFU.length) {
        await conn.execute(
          'UPDATE FollowUp SET followupDate = ? WHERE complaintID = ?', [followupDate, cid]
        );
      } else {
        await conn.execute(
          'INSERT INTO FollowUp (followupDate, complaintID) VALUES (?, ?)', [followupDate, cid]
        );
      }
    }

    await conn.commit();
    res.json({ message: 'Complaint updated successfully.' });
  } catch (err) {
    await conn.rollback();
    next(err);
  } finally {
    conn.release();
  }
});

// DELETE /api/complaints/:id — Admin only
router.delete('/:id', authenticate, requireRole('Admin'), async (req, res, next) => {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const cid = req.params.id;

    await conn.execute('DELETE FROM FollowUp          WHERE complaintID = ?', [cid]);
    await conn.execute('DELETE FROM ComplaintActions  WHERE complaintID = ?', [cid]);
    await conn.execute('DELETE FROM ComplaintCauses   WHERE complaintID = ?', [cid]);
    await conn.execute('DELETE FROM ComplaintStatus   WHERE complaintID = ?', [cid]);
    const [result] = await conn.execute('DELETE FROM Complaint WHERE complaintID = ?', [cid]);

    if (!result.affectedRows) {
      await conn.rollback();
      return res.status(404).json({ error: 'Complaint not found.' });
    }

    await conn.commit();
    res.json({ message: 'Complaint deleted.' });
  } catch (err) {
    await conn.rollback();
    next(err);
  } finally {
    conn.release();
  }
});

module.exports = router;
