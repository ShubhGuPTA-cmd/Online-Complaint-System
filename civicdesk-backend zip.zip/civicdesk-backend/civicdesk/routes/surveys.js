// ─────────────────────────────────────────────
//  routes/surveys.js — Site Surveys
// ─────────────────────────────────────────────

const express = require('express');
const router  = express.Router();
const pool    = require('../db');
const { authenticate, requireRole } = require('../middleware/auth');

// GET /api/surveys
router.get('/', authenticate, async (req, res, next) => {
  try {
    const [rows] = await pool.execute(
      `SELECT s.surveyID, s.date, s.nationalID, c.name AS complainantName, c.address
       FROM SiteSurvey s
       JOIN Complainant c ON s.nationalID = c.nationalID
       ORDER BY s.date DESC`
    );
    res.json(rows);
  } catch (err) {
    next(err);
  }
});

// GET /api/surveys/:id
router.get('/:id', authenticate, async (req, res, next) => {
  try {
    const [rows] = await pool.execute(
      `SELECT s.*, c.name AS complainantName, c.address
       FROM SiteSurvey s
       JOIN Complainant c ON s.nationalID = c.nationalID
       WHERE s.surveyID = ?`,
      [req.params.id]
    );
    if (!rows.length) return res.status(404).json({ error: 'Survey not found.' });
    res.json(rows[0]);
  } catch (err) {
    next(err);
  }
});

// POST /api/surveys — Admin or Officer only
router.post('/', authenticate, requireRole('Admin', 'Officer'), async (req, res, next) => {
  const { nationalID, date } = req.body;
  if (!nationalID) return res.status(400).json({ error: 'nationalID is required.' });

  try {
    const surveyDate = date || new Date().toISOString().split('T')[0];
    const [result] = await pool.execute(
      'INSERT INTO SiteSurvey (date, nationalID) VALUES (?, ?)',
      [surveyDate, nationalID]
    );
    res.status(201).json({ message: 'Survey created.', surveyID: result.insertId });
  } catch (err) {
    next(err);
  }
});

// DELETE /api/surveys/:id — Admin only
router.delete('/:id', authenticate, requireRole('Admin'), async (req, res, next) => {
  try {
    const [result] = await pool.execute('DELETE FROM SiteSurvey WHERE surveyID = ?', [req.params.id]);
    if (!result.affectedRows) return res.status(404).json({ error: 'Survey not found.' });
    res.json({ message: 'Survey deleted.' });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
