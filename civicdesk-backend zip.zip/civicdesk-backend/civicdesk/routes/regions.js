// ─────────────────────────────────────────────
//  routes/regions.js — Governorates & Regions
// ─────────────────────────────────────────────

const express = require('express');
const router  = express.Router();
const pool    = require('../db');
const { authenticate } = require('../middleware/auth');

// GET /api/governorates
router.get('/governorates', authenticate, async (req, res, next) => {
  try {
    const [rows] = await pool.execute('SELECT * FROM Governorates ORDER BY governName ASC');
    res.json(rows);
  } catch (err) {
    next(err);
  }
});

// GET /api/regions
router.get('/regions', authenticate, async (req, res, next) => {
  try {
    const [rows] = await pool.execute(
      `SELECT r.id, r.regionName, r.governID, g.governName
       FROM Regions r
       JOIN Governorates g ON r.governID = g.governID
       ORDER BY g.governName, r.regionName`
    );
    res.json(rows);
  } catch (err) {
    next(err);
  }
});

// GET /api/regions/:governID — regions for a specific governorate
router.get('/regions/:governID', authenticate, async (req, res, next) => {
  try {
    const [rows] = await pool.execute(
      'SELECT * FROM Regions WHERE governID = ? ORDER BY regionName',
      [req.params.governID]
    );
    res.json(rows);
  } catch (err) {
    next(err);
  }
});

module.exports = router;
