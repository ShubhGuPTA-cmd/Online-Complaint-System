// ─────────────────────────────────────────────
//  routes/stats.js — Dashboard Statistics
// ─────────────────────────────────────────────

const express = require('express');
const router  = express.Router();
const pool    = require('../db');
const { authenticate } = require('../middleware/auth');

// GET /api/stats
router.get('/', authenticate, async (req, res, next) => {
  try {
    const [[{ total }]]      = await pool.execute('SELECT COUNT(*) AS total FROM Complaint');
    const [[{ registered }]] = await pool.execute('SELECT COUNT(*) AS registered FROM ComplaintStatus WHERE id = 1');
    const [[{ inProgress }]] = await pool.execute('SELECT COUNT(*) AS inProgress FROM ComplaintStatus WHERE id = 2');
    const [[{ resolved }]]   = await pool.execute('SELECT COUNT(*) AS resolved   FROM ComplaintStatus WHERE id = 3');
    const [[{ users }]]      = await pool.execute('SELECT COUNT(*) AS users      FROM User');
    const [[{ surveys }]]    = await pool.execute('SELECT COUNT(*) AS surveys    FROM SiteSurvey');

    // Recent 7 days
    const [[{ recent }]] = await pool.execute(
      `SELECT COUNT(*) AS recent FROM Complaint
       WHERE complaintDate >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)`
    );

    res.json({ total, registered, inProgress, resolved, users, surveys, recent });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
