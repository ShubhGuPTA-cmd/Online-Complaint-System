// ─────────────────────────────────────────────
//  routes/auth.js — Login / Auth Routes
// ─────────────────────────────────────────────

const express = require('express');
const jwt     = require('jsonwebtoken');
const router  = express.Router();
const pool    = require('../db');

// POST /api/login
router.post('/login', async (req, res, next) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required.' });
  }

  try {
    const [rows] = await pool.execute(
      `SELECT u.*, r.roleType
       FROM User u
       JOIN Roles r ON u.roleId = r.roleId
       WHERE u.email = ?`,
      [email]
    );

    if (!rows.length) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    const user = rows[0];

    // Plain text compare — swap for bcrypt in production:
    // const match = await bcrypt.compare(password, user.password);
    const match = password === user.password;

    if (!match) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    // Sign JWT
    const token = jwt.sign(
      {
        userId:   user.userId,
        email:    user.email,
        roleId:   user.roleId,
        roleType: user.roleType,
        username: user.username,
      },
      process.env.JWT_SECRET || 'secret',
      { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
    );

    // Return user without password
    const { password: _, ...safeUser } = user;
    res.json({ message: 'Login successful.', token, user: safeUser });

  } catch (err) {
    next(err);
  }
});

// GET /api/me — get current user from token
router.get('/me', require('../middleware/auth').authenticate, async (req, res) => {
  res.json({ user: req.user });
});

module.exports = router;
