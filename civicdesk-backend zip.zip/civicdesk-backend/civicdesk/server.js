// ─────────────────────────────────────────────
//  server.js — CivicDesk API Entry Point
//  Run:   node server.js
//  Dev:   nodemon server.js
// ─────────────────────────────────────────────

require('dotenv').config();
const express      = require('express');
const cors         = require('cors');
const path         = require('path');
const errorHandler = require('./middleware/errorHandler');

// ── Route Imports ──────────────────────────
const authRoutes        = require('./routes/auth');
const userRoutes        = require('./routes/users');
const complainantRoutes = require('./routes/complainants');
const complaintRoutes   = require('./routes/complaints');
const statsRoutes       = require('./routes/stats');
const regionRoutes      = require('./routes/regions');
const surveyRoutes      = require('./routes/surveys');
const questionRoutes    = require('./routes/questions');

// ── App Setup ──────────────────────────────
const app  = express();
const PORT = process.env.PORT || 5000;

// ── Middleware ─────────────────────────────
app.use(cors({
  origin: '*', // Restrict in production: ['http://localhost:5000']
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ── Serve Static Frontend ──────────────────
// Place index.html inside the /public folder
app.use(express.static(path.join(__dirname, 'public')));

// ── API Routes ─────────────────────────────
app.use('/api',             authRoutes);        // POST /api/login, GET /api/me
app.use('/api/users',       userRoutes);        // CRUD /api/users
app.use('/api/complainants', complainantRoutes); // CRUD /api/complainants
app.use('/api/complaints',  complaintRoutes);   // CRUD /api/complaints
app.use('/api/stats',       statsRoutes);       // GET  /api/stats
app.use('/api',             regionRoutes);      // GET  /api/governorates, /api/regions
app.use('/api/surveys',     surveyRoutes);      // CRUD /api/surveys
app.use('/api/questions',   questionRoutes);    // CRUD /api/questions

// ── Health Check ───────────────────────────
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    service: 'CivicDesk API',
    timestamp: new Date().toISOString(),
  });
});

// ── SPA Fallback ───────────────────────────
// Sends index.html for any non-API route
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// ── Global Error Handler ───────────────────
app.use(errorHandler);

// ── Start Server ───────────────────────────
app.listen(PORT, () => {
  console.log('');
  console.log('  ╔══════════════════════════════════════╗');
  console.log(`  ║   🚀  CivicDesk API — Port ${PORT}      ║`);
  console.log('  ╠══════════════════════════════════════╣');
  console.log(`  ║   Frontend : http://localhost:${PORT}   ║`);
  console.log(`  ║   API Base : http://localhost:${PORT}/api║`);
  console.log(`  ║   Health   : http://localhost:${PORT}/api/health ║`);
  console.log('  ╚══════════════════════════════════════╝');
  console.log('');
});
